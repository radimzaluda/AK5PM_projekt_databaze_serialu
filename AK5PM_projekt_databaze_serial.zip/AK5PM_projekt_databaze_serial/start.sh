#vytvoreni nove aplikace ionic fw + angular
ionic start AK5PM_PROJEKT_DATABAZE_SERIALU blank --type=angular

#vytvoreni stranek(obrazovek) + vytvoreni sluzby
ionic g page pages/serialy
ionic g page pages/serialinfo
ionic g service services/serialinfo

#vytvoreni stranek(obrazovek) + vytvoreni sluzby
ionic g page pages/movies
ionic g page pages/movieinfo
ionic g service services/movie

#vlastni splash screen
npm install -g cordova-res

cordova-res android --skip-config --copy

#přidání androidu
ionic cap add android