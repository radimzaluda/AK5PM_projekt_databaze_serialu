import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SerialinfoService } from 'src/app/services/serialinfo.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-serialinfo',
  templateUrl: './serialinfo.page.html',
  styleUrls: ['./serialinfo.page.scss'],
})
export class SerialinfoPage implements OnInit {

  serial=null as any;
imageBaseUrl = environment.images;

  constructor(private route: ActivatedRoute, private serialinfoservice: SerialinfoService) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.serialinfoservice.getSerialInfo(id).subscribe((res) =>
    {console.log(res);
   this.serial=res;
   });
  }

}
