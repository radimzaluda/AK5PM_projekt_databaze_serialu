import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'AK5PM_project_database_films_serials',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
